<div class="modal fade" id="editModal<?php echo e($pilot->id); ?>" tabindex="-1" role="dialog">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Editar Piloto: <?php echo e($pilot->name); ?></h5>
                                        <button class="btn-close" type="button" data-bs-dismiss="modal"></button>
                                    </div>
                                    <form action="<?php echo e(route('pilots.update', $pilot->id)); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                                        <div class="modal-body">
                                            <div class="col-md-5 mb-3">
                                                <label class="form-label">Tipo de Documento</label>
                                                <select class="form-select" name="doc_type" required>
                                                    <option value="DUI" <?php echo e((old('doc_type') ?? $pilot->doc_type ?? '') == 'DUI' ? 'selected' : ''); ?>>DUI</option>
                                                    <option value="Extrajero" <?php echo e((old('doc_type') ?? $pilot->doc_type ?? '') == 'Extrajero' ? 'selected' : ''); ?>>Documento de extranjería</option>
                                                    <option value="Pasaporte" <?php echo e((old('doc_type') ?? $pilot->doc_type ?? '') == 'Pasaporte' ? 'selected' : ''); ?>>Pasaporte</option>
                                                    <option value="NIT" <?php echo e((old('doc_type') ?? $pilot->doc_type ?? '') == 'NIT' ? 'selected' : ''); ?>>NIT</option>
                                                </select>
                                            </div>
                                            <div class="col-md-7 mb-3">
                                                <label class="form-label">Número de Identificación (NUIP/DUI)</label>
                                                <input class="form-control <?php $__errorArgs = ['doc_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    name="doc_number" 
                                                    type="text" 
                                                    value="<?php echo e(old('doc_number') ?? $pilot->doc_number ?? ''); ?>" 
                                                    placeholder="Ej: 00000000-0" 
                                                    required>
                                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['doc_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">Este número de identificación ya existe.</div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Nombre</label>
                                                <input class="form-control" name="name" type="text" value="<?php echo e($pilot->name); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Email</label>
                                                <input class="form-control" name="email" type="email" value="<?php echo e($pilot->email); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">No. Licencia</label>
                                                <input class="form-control" name="license_number" type="text" value="<?php echo e($pilot->license_number); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Vencimiento Médica</label>
                                                <input class="form-control" name="medical_certificate_expiry" type="date" value="<?php echo e($pilot->medical_certificate_expiry); ?>" required>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Teléfono</label>
                                                <input class="form-control" name="phone" type="text" value="<?php echo e($pilot->phone); ?>">
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label">Foto de Perfil Actual (2Mb max.)</label>
                                                <div class="mb-2">
                                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pilot->profile_photo): ?>
                                                        <img src="<?php echo e(asset('storage/' . $pilot->profile_photo)); ?>" class="img-thumbnail" width="100">
                                                    <?php else: ?>
                                                        <span class="text-muted">Sin foto actual</span>
                                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                                </div>
                                                <input type="file" name="profile_photo" class="form-control" accept="image/*">
                                                <small class="text-muted">Deje vacío para mantener la foto actual.</small>
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button class="btn btn-secondary" type="button" data-bs-dismiss="modal">Cerrar</button>
                                            <button class="btn btn-primary" type="submit">Actualizar Cambios</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
<?php /**PATH E:\Herd\bitacoras\resources\views/pilots/partials/update_modal.blade.php ENDPATH**/ ?>