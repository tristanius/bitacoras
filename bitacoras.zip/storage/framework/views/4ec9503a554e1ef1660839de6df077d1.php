   <!-- latest jquery-->
   <script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/bootstrap/popper.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/bootstrap/bootstrap.bundle.min.js')); ?>"></script>
   <!-- feather icon js-->
   <script src="<?php echo e(asset('assets/js/icons/feather-icon/feather.min.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/icons/feather-icon/feather-icon.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/scrollbar/simplebar.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/scrollbar/custom.js')); ?>"></script>
   <!-- Sidebar jquery-->
   <script src="<?php echo e(asset('assets/js/config.js')); ?>"></script>
   <script src="<?php echo e(asset('assets/js/sidebar-menu.js')); ?>"></script>
   <?php echo $__env->yieldContent('scripts'); ?>
   <script src="<?php echo e(asset('assets/js/tooltip-init.js')); ?>"></script>
   <!-- Theme js-->
   <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
   
<?php /**PATH E:\Herd\bitacoras\resources\views/layout/script.blade.php ENDPATH**/ ?>