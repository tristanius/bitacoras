

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('partials.monserrat_font', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-6">
                <h3>Gestión de Pilotos</h3>
            </div>
            <div class="col-6">
                <button class="btn btn-primary float-end" type="button" data-bs-toggle="modal" data-bs-target="#createPilotModal">
                    <i class="fa fa-plus"></i> Nuevo Piloto
                </button>
            </div>
        </div>
    </div>
    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['registration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="text-danger mt-1" style="color: #ff8300 !important;">
            <strong>La matrícula (registration) "<?php echo e(old('registration')); ?>" ya existe.</strong>
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/datatables.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/datatable-extension.css')); ?>">
<?php $__env->stopSection(); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover display" id="basic-1">
                    <thead>
                        <tr>
                            <th>No. de identificación</th>
                            <th>Tipo de documento</th>
                            <th>Nombre</th>
                            <th>Licencia</th>
                            <th>Certi. Médico exp.</th>
                            <th>Teléfono</th>
                            <th>Estado</th>
                            <th>Cambiar estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $pilots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pilot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                        <tr>
                            <td><?php echo e($pilot->doc_number); ?></td>
                            <td><?php echo e($pilot->doc_type); ?></td>
                            <td>
                                <div class="d-flex align-items-center">
                                    <div class="symbol symbol-circle symbol-40px me-3">
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($pilot->profile_photo): ?>
                                            <img src="<?php echo e(asset('storage/' . $pilot->profile_photo)); ?>" alt="Avatar" style="object-fit: cover;" height="50">
                                        <?php else: ?>
                                            <div class="symbol-label fs-4 fw-bold bg-soft-primary text-primary">
                                                <?php echo e(substr($pilot->name, 0, 1)); ?>

                                            </div>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </div>
                                    <div class="d-flex flex-column">
                                        <a href="#" class="text-dark fw-bolder text-hover-primary fs-6"><?php echo e($pilot->name); ?></a>
                                        <span class="text-muted fw-bold" style="font-size: 0.8rem;"><?php echo e($pilot->email); ?></span>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($pilot->license_number); ?></td>
                            <td class="<?php echo e(\Carbon\Carbon::parse($pilot->medical_certificate_expiry)->isPast() ? 'text-danger fw-bold' : ''); ?>">
                                <?php echo e($pilot->medical_certificate_expiry); ?>

                            </td>
                            <td><?php echo e($pilot->phone); ?></td>
                            <td>
                                <span class="badge <?php echo e($pilot->is_active ? 'bg-success' : 'bg-danger'); ?>">
                                    <?php echo e($pilot->is_active ? 'Activo' : 'Inactivo'); ?>

                                </span>
                            </td>
                            <td>
                                <form action="<?php echo e(route('pilot.toggle', $pilot)); ?>" method="POST">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <button class="btn btn-sm btn-<?php echo e($pilot->is_active ? 'warning' : 'success'); ?>"> <i class="<?php echo e($pilot->is_active ? 'fa fa-pause-circle-o':'fa fa-check'); ?>"></i></button>
                                </form>
                            </td>
                            <td>
                                <button class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?php echo e($pilot->id); ?>" style="color:navy">
                                    <i class="fa fa-edit"></i>
                                </button>     
                                
                                <form action="<?php echo e(route('pilots.destroy', $pilot->id)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('¿Estás seguro de eliminar este piloto? Esta acción no se puede deshacer.')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>

                        <?php echo $__env->make('pilots.partials.update_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('pilots.partials.create_modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        // Esto activará el buscador, paginación y ordenamiento automáticamente si Koho tiene DataTables
        $('.table').DataTable({
            language: {
                url: 'https://cdn.datatables.net/plug-ins/1.13.4/i18n/es-ES.json'
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Herd\bitacoras\resources\views/pilots/index.blade.php ENDPATH**/ ?>