
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('partials.monserrat_font', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="page-title">
        <div class="row">
            <div class="col-6">
                <h3>Gestión de Aeronaves</h3>
            </div>
            <div class="col-6 text-end">
                </div>
        </div>
    </div>

    <div>
        <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#createAircraftModal">
            <i class="fa fa-plus"></i> Nueva Aeronave
        </button>
        <hr>
        
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__errorArgs = ['registration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="text-danger mt-1" style="color: #ff8300 !important;">
                <strong>La matrícula (registration) "<?php echo e(old('registration')); ?>" ya existe.</strong>
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
    </div>    
    
    <div class="row">
        <div class="col-sm-12">
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover" id="tabla-aircrafts">
                            <thead>
                                <tr>
                                    <th>Matricula</th>
                                    <th>Marca / Modelo</th>
                                    <th>Clase (Categorías)</th>                                    
                                    <th>estado</th>
                                    <th>Cambiar</th>
                                    <th>acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $aircrafts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aircraft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <tr>
                                    <td><strong><?php echo e($aircraft->registration); ?></strong></td>
                                    <td><?php echo e($aircraft->aircraft_model->manufacturer); ?> <?php echo e($aircraft->aircraft_model->name); ?></td>
                                    <td><span class="badge badge-light-success"><?php echo e($aircraft->aircraft_model->category->name); ?></span></td>
                                    <td>
                                        <span class="badge <?php echo e($aircraft->is_active ? 'bg-success' : 'bg-danger'); ?>">
                                            <?php echo e($aircraft->is_active ? 'Activo' : 'Inactivo'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <form action="<?php echo e(route('aircraft.toggle', $aircraft)); ?>" method="POST">
                                            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                            <button class="btn btn-sm btn-light"><i class="fa fa-rotate-right"></i> <?php echo e($aircraft->is_active ? 'Desactivar' : 'Activar'); ?></button>
                                        </form>
                                    </td>
                                    <td>
                                        <button class="btn btn-warning btn-sm" onclick="editAircraft(<?php echo e($aircraft->id); ?>, '<?php echo e($aircraft->registration); ?>', '<?php echo e($aircraft->aircraft_model->id); ?>')">
                                            <i class="fa fa-edit"></i>
                                        </button>
                                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
                                            <form action="<?php echo e(route('aircraft.destroy', $aircraft)); ?>" method="POST" style="display:inline;" onsubmit="return confirm('¿Estás seguro de eliminar este aeropuerto?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-sm btn-danger">
                                                    <i class="fa fa-trash"></i> 
                                                </button>
                                            </form>
                                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                    </td>
                                </tr>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('aircrafts.update', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('aircrafts.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/datatables.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/vendors/datatable-extension.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('assets/js/datatable/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/datatable/datatable-extension/dataTables.buttons.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#tabla-aircrafts').DataTable({
            language: { url: 'https://cdn.datatables.net/plug-ins/1.13.6/i18n/es-ES.json' }
        });
    });

    function editAircraft(id, registration, model_id) {
        // Seteamos la URL del form
        $('#formeditAircraft').attr('action', '/aircraft/' + id);
        
        // Llenamos los campos del modal
        
        $('#edit_registration').val(registration);
        $('#edit_aircraft_model_id').val(model_id); // Esto seleccionará el option correcto
        
        // Mostramos el modal de edición
        var editModal = new bootstrap.Modal(document.getElementById('modaleditAircraft'));
        editModal.show();
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Herd\bitacoras\resources\views/aircrafts/index.blade.php ENDPATH**/ ?>