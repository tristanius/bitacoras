

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('partials.monserrat_font', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0">Detalle de Bitácora: Vuelo #<?php echo e($log_entry->id); ?></h4>
        <div class="page-title-right">
            <a href="<?php echo e(route('log_entries.index')); ?>" class="btn btn-secondary btn-sm shadow-sm">
                <i class="fa fa-arrow-left"></i> Volver al Listado
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow-none border">
                <div class="card-body text-center">
                    <div class="avatar-md mb-3 mx-auto">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log_entry->pilot->photo): ?>
                            <img src="<?php echo e(asset('storage/'.$log_entry->pilot->photo)); ?>" class="rounded-circle img-thumbnail" style="width: 100px; height: 100px;">
                        <?php else: ?>
                            <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto" style="width: 100px; height: 100px;">
                                <h1 class="mb-0"><?php echo e(substr($log_entry->pilot->name, 0, 1)); ?></h1>
                            </div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <h5 class="mb-1"><?php echo e($log_entry->pilot->name); ?></h5>
                    <p class="text-muted text-uppercase small fw-bold">Piloto al Mando (PIC)</p>
                    
                    <hr>
                    
                    <div class="row text-start mt-4">
                        <div class="col-6 mb-3">
                            <label class="text-muted small d-block">Aeronave</label>
                            <span class="fw-bold text-primary"><?php echo e($log_entry->aircraft->registration); ?></span>
                        </div>
                        <div class="col-6 mb-3">
                            <label class="text-muted small d-block">Fecha de Vuelo</label>
                            <span class="fw-bold"><?php echo e(\Carbon\Carbon::parse($log_entry->date)->format('d/m/Y')); ?></span>
                        </div>
                        <div class="col-12">
                            <label class="text-muted small d-block">Instructor Asignado</label>
                            <span class="fw-bold"><?php echo e($log_entry->instructor->name ?? 'Vuelo Solo / Sin Instructor'); ?></span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card bg-dark text-white shadow-none">
                <div class="card-body">
                    <h5 class="card-title text-white">Contadores Hobbs</h5>
                    <hr class="border-light">
                    <div class="d-flex justify-content-between mb-2">
                        <span>Hobbs Salida:</span>
                        <span class="fw-bold text-info"><?php echo e(number_format($log_entry->hobbs_out, 1)); ?></span>
                    </div>
                    <div class="d-flex justify-content-between mb-2">
                        <span>Hobbs Entrada:</span>
                        <span class="fw-bold text-info"><?php echo e(number_format($log_entry->hobbs_in, 1)); ?></span>
                    </div>
                    <div class="alert alert-light py-2 text-center text-dark fw-bold mb-0 mt-3">
                        TOTAL TIEMPO: <?php echo e(number_format($log_entry->total_time, 2)); ?> hrs
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-none border">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h5 class="card-title mb-0">Detalles de la Misión</h5>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($log_entry->validated): ?>
                            <span class="badge bg-success p-2 px-3"><i class="fa fa-check-circle"></i> VUELO VALIDADO</span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark p-2 px-3"><i class="fa fa-clock-o"></i> PENDIENTE DE VALIDACIÓN</span>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>

                    <div class="row text-center mb-4">
                        <div class="col-md-5">
                            <h2 class="mb-0 text-primary"><?php echo e($log_entry->origin->icao_code); ?></h2>
                            <small class="text-muted"><?php echo e($log_entry->origin->name); ?></small>
                        </div>
                        <div class="col-md-2 d-flex align-items-center justify-content-center">
                            <i class="fa fa-plane fa-2x text-muted"></i>
                        </div>
                        <div class="col-md-5">
                            <h2 class="mb-0 text-primary"><?php echo e($log_entry->destination->icao_code); ?></h2>
                            <small class="text-muted"><?php echo e($log_entry->destination->name); ?></small>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card shadow-none border">
                <div class="card-body">
                    <h5 class="card-title mb-4">Distribución de Tiempos y Condiciones</h5>
                    <div class="table-responsive">
                        <table class="table table-sm table-bordered text-center">
                            <thead class="bg-light">
                                <tr>
                                    <th>PIC</th><th>SIC</th><th>Solo</th><th>Dual</th><th>CFI</th><th>Sim</th><th>Night</th><th>XC</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($log_entry->pic_time); ?></td><td><?php echo e($log_entry->sic_time); ?></td>
                                    <td><?php echo e($log_entry->solo_time); ?></td><td><?php echo e($log_entry->dual_time); ?></td>
                                    <td><?php echo e($log_entry->cfi_time); ?></td><td><?php echo e($log_entry->simulator_time); ?></td>
                                    <td><?php echo e($log_entry->night_time); ?></td><td><?php echo e($log_entry->xc_time); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-md-6">
                    <div class="card shadow-none border h-100">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Observaciones / Remarks</h5>
                            <p class="text-muted italic">"<?php echo e($log_entry->remarks ?? 'Sin observaciones adicionales.'); ?>"</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card shadow-none border h-100">
                        <div class="card-body">
                            <h5 class="card-title mb-3">Anexos / Evidencias</h5>
                            <ul class="list-unstyled">
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $log_entry->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                    <li class="mb-2">
                                        <i class="fa fa-file-pdf-o text-danger"></i> 
                                        <a href="<?php echo e(asset('storage/'.$file->path)); ?>" target="_blank" class="text-decoration-none">
                                            <?php echo e($file->name); ?>

                                        </a>
                                    </li>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                    <li class="text-muted">No se adjuntaron archivos.</li>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!$log_entry->validated && auth()->id() == $log_entry->instructor_id): ?>
                <div class="card border-primary mt-4 bg-light">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <h5 class="text-primary mb-1">Confirmación de Instrucción</h5>
                            <p class="mb-0 small">Como instructor asignado, certifique que los datos anteriores son veraces.</p>
                        </div>
                        <form action="<?php echo e(route('log_entries.validate', $log_entry->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-success p-3 fw-bold shadow">
                                <i class="fa fa-check"></i> DAR EL OK / VALIDAR VUELO
                            </button>
                        </form>
                    </div>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Herd\bitacoras\resources\views/log_entries/show.blade.php ENDPATH**/ ?>