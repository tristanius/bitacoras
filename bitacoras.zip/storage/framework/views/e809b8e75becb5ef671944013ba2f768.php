<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-10 p-0 footer-left">
                <p class="mb-0">Todos los derechos intelectuales reservados a Weppy Digital, desarrollador de la app.</p>
            </div>
            <div class="col-2 p-0 footer-right"> <i class="fa fa-heart font-danger"> </i></div>
        </div>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-10 p-0 footer-left">
                <p class="mb-0">Copyright 2023 © Koho theme by pixelstrap</p>
            </div>
            <div class="col-2 p-0 footer-right"> <i class="fa fa-heart font-danger"> </i></div>
        </div>
    </div>
</footer>
<?php /**PATH E:\Herd\bitacoras\resources\views/layout/footer.blade.php ENDPATH**/ ?>