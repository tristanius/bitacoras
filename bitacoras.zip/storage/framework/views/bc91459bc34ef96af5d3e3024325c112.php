

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('partials.monserrat_font', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<br>
<div class="container-fluid">
    <div class="page-title-box d-sm-flex align-items-center justify-content-between">
        <h4 class="mb-sm-0">Editar Registro de Vuelo (Log Entry) #<?php echo e($logEntry->id); ?></h4>
    </div>

    
    <form action="<?php echo e(route('log_entries.update', $logEntry->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?> 

        <div class="row">
            <div class="col-lg-8">
                <div class="card shadow-none border">
                    <div class="card-body">
                        <h5 class="card-title mb-4">1. Datos de la Misión</h5>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label>Fecha</label>
                                <input type="date" name="date" class="form-control" value="<?php echo e(old('date', $logEntry->date)); ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label>Aeronave</label>
                                <select name="aircraft_id" class="form-select" required>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $aircrafts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aircraft): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <option value="<?php echo e($aircraft->id); ?>" <?php echo e(old('aircraft_id', $logEntry->aircraft_id) == $aircraft->id ? 'selected' : ''); ?>> 
                                            <?php echo e($aircraft->registration); ?> - <?php echo e($aircraft->model->name ?? 'N/A'); ?> 
                                        </option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label>Instructor (Opcional)</label>
                                <select name="instructor_id" class="form-select select2-instructor">
                                    <option value="">-- Vuelo Solo --</option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $instructors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $instructor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <option value="<?php echo e($instructor->id); ?>" <?php echo e(old('instructor_id', $logEntry->instructor_id) == $instructor->id ? 'selected' : ''); ?>>
                                            <?php echo e($instructor->name); ?>

                                        </option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                            </div>
                        </div>

                        <div class="row mt-2">
                            <div class="col-md-6 mb-3">
                                <label>Origen</label>
                                <select name="origin_id" class="form-select" required>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $airports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <option value="<?php echo e($airport->id); ?>" <?php echo e(old('origin_id', $logEntry->origin_id) == $airport->id ? 'selected' : ''); ?>>
                                            <?php echo e($airport->icao_code); ?> - <?php echo e($airport->name); ?>

                                        </option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label>Destino</label>
                                <select name="destination_id" class="form-select" required>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $airports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <option value="<?php echo e($airport->id); ?>" <?php echo e(old('destination_id', $logEntry->destination_id) == $airport->id ? 'selected' : ''); ?>>
                                            <?php echo e($airport->icao_code); ?> - <?php echo e($airport->name); ?>

                                        </option>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card shadow-none border bg-dark text-white shadow-none">
                    <div class="card-body">
                        <h5 class="card-title mb-3">2. Cómputo de Tiempo (Hobbs)</h5>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Hobbs Salida (Out)</label>
                                <input type="number" step="0.1" name="hobbs_out" id="hobbs_out" class="form-control form-control-lg text-primary" value="<?php echo e(old('hobbs_out', $logEntry->hobbs_out)); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold">Hobbs Entrada (In)</label>
                                <input type="number" step="0.1" name="hobbs_in" id="hobbs_in" class="form-control form-control-lg text-success" value="<?php echo e(old('hobbs_in', $logEntry->hobbs_in)); ?>" required>
                            </div>
                        </div>
                    </div>
                </div>

                
                <div class="card shadow-none border">
                    <div class="card-body">
                        <h5 class="card-title mb-3">3. Tiempos Detallados (Hrs)</h5>
                        <div class="row">
                            <?php
                                $tiempos = ['pic_time' => 'PIC', 'sic_time' => 'SIC', 'solo_time' => 'Solo', 'dual_time' => 'Dual Received', 'cfi_time' => 'As CFI', 'xc_time' => 'Cross Country', 'night_time' => 'Night'];
                            ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $tiempos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                <div class="col-md-3 mb-2">
                                    <label class="small"><?php echo e($label); ?></label>
                                    <input type="number" step="0.1" name="<?php echo e($key); ?>" class="form-control form-control-sm" value="<?php echo e(old($key, $logEntry->$key)); ?>">
                                </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                        </div>
                    </div>
                </div>

                <div class="card shadow-none border">
                    <div class="card-body">
                        <h5 class="card-title mb-3">4. Otros y Observaciones</h5>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Landings (Day/Night)</label>
                                <div class="input-group">
                                    <input type="number" name="landings_day" class="form-control" placeholder="Day" value="<?php echo e(old('landings_day', $logEntry->landings_day)); ?>">
                                    <input type="number" name="landings_night" class="form-control" placeholder="Night" value="<?php echo e(old('landings_night', $logEntry->landings_night)); ?>">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <label>Observaciones (Remarks)</label>
                                <textarea name="remarks" class="form-control" rows="3"><?php echo e(old('remarks', $logEntry->remarks)); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="card shadow-none border">
                    <div class="card-body">
                        <h5 class="card-title mb-3">4. Otros, Observaciones y Adjuntos</h5>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label>Landings (Day/Night)</label>
                                <div class="input-group">
                                    <input type="number" name="landings_day" class="form-control" placeholder="Day" value="<?php echo e(old('landings_day', $logEntry->landings_day)); ?>">
                                    <input type="number" name="landings_night" class="form-control" placeholder="Night" value="<?php echo e(old('landings_night', $logEntry->landings_night)); ?>">
                                </div>
                            </div>

                            
                            <div class="col-md-6 mb-3">
                                <label class="fw-bold text-primary">Archivos Adjuntos Actuales</label>
                                <ul class="list-group list-group-flush border rounded p-2" style="max-height: 150px; overflow-y: auto;">
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $logEntry->attachments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
                                        <li class="list-group-item d-flex justify-content-between align-items-center py-1">
                                            <small><i class="fa fa-file-pdf-o text-danger"></i> <?php echo e(Str::limit($file->name, 25)); ?></small>
                                            <a href="<?php echo e(asset('storage/'.$file->path)); ?>" target="_blank" class="btn btn-xs btn-outline-info">Ver</a>
                                        </li>
                                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
                                        <li class="list-group-item text-muted small">No hay archivos previos</li>
                                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                                </ul>
                            </div>

                            <div class="col-md-12 mb-3">
                                <label class="fw-bold">Subir Nuevos Archivos (PDF, Imágenes)</label>
                                <input type="file" name="files[]" class="form-control" multiple>
                                <small class="text-muted">Si selecciona archivos nuevos, estos se añadirán a los ya existentes.</small>
                            </div>

                            <div class="col-md-12">
                                <label>Observaciones (Remarks)</label>
                                <textarea name="remarks" class="form-control" rows="3"><?php echo e(old('remarks', $logEntry->remarks)); ?></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            
            <div class="col-lg-4">
                <div class="card shadow-none border bg-dark text-white sticky-top" style="top: 20px;">
                    <div class="card-body text-center">
                        <h5 class="card-title text-white">Resumen del Vuelo</h5>
                        <hr class="border-light">
                        <h1 class="display-4 fw-bold text-info" id="total_display"><?php echo e(number_format($logEntry->total_time, 2)); ?></h1>
                        <p class="mb-4">Horas Totales Calculadas</p>
                        
                        <input type="hidden" name="total_time" id="total_time" value="<?php echo e($logEntry->total_time); ?>">

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary btn-lg fw-bold shadow">
                                <i class="fa fa-save"></i> Guardar Cambios
                            </button>
                            <a href="<?php echo e(route('log_entries.index')); ?>" class="btn btn-outline-danger">
                                Cancelar
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        const hOut = document.getElementById('hobbs_out');
        const hIn = document.getElementById('hobbs_in');
        const totalInp = document.getElementById('total_time');
        const totalDisp = document.getElementById('total_display');

        function calcular() {
            const res = (parseFloat(hIn.value) || 0) - (parseFloat(hOut.value) || 0);
            const final = res > 0 ? res.toFixed(2) : 0.00;
            totalInp.value = final;
            totalDisp.innerText = final;
        }

        hOut.addEventListener('input', calcular);
        hIn.addEventListener('input', calcular);
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Herd\bitacoras\resources\views/log_entries/edit.blade.php ENDPATH**/ ?>