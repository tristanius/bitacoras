<!DOCTYPE html>
<html>
<head>
    <title>Logbook Report</title>
    <style>
        body { font-family: sans-serif; font-size: 10px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { border: 1px solid #000; padding: 4px; text-align: center; }
        th { background-color: #f2f2f2; }
        .header { text-align: center; margin-bottom: 20px; }
        .footer { position: fixed; bottom: 0; width: 100%; text-align: right; font-size: 8px; }
    </style>
</head>
<body>
    <div class="header">
        <h2>REGISTRO DE VUELO - BITÁCORA DE PILOTO</h2>
        <p>Piloto: <strong><?php echo e($pilot->name); ?></strong> | Periodo: <?php echo e($request->start_date); ?> al <?php echo e($request->end_date); ?></p>
    </div>

    <table>
        <thead>
            <tr>
                <th rowspan="2">Fecha</th>
                <th rowspan="2">Avión</th>
                <th rowspan="2">Class</th>
                <th colspan="2">Ruta</th>
                <th colspan="2">Hobbs</th>
                <th rowspan="2">Total</th>
                <th colspan="5">Condiciones / Tipo de Tiempo</th>
                <th rowspan="2">Instructor</th>
            </tr>
            <tr>
                <th>Origen</th><th>Dest</th>
                <th>Out</th><th>In</th>
                <th>PIC</th><th>SIC</th><th>Solo</th><th>Dual</th><th>XC</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <tr>
                <td><?php echo e($entry->date); ?></td>
                <td><?php echo e($entry->aircraft->registration); ?></td>
                <td><?php echo e($entry->aircraft->model->name); ?> / <?php echo e($entry->aircraft->model->category->name); ?></td>
                <td><?php echo e($entry->origin->icao_code); ?></td>
                <td><?php echo e($entry->destination->icao_code); ?></td>
                <td><?php echo e($entry->hobbs_out); ?></td>
                <td><?php echo e($entry->hobbs_in); ?></td>
                <td><strong><?php echo e($entry->total_time); ?></strong></td>
                <td><?php echo e($entry->pic_time); ?></td>
                <td><?php echo e($entry->sic_time); ?></td>
                <td><?php echo e($entry->solo_time); ?></td>
                <td><?php echo e($entry->dual_time); ?></td>
                <td><?php echo e($entry->xc_time); ?></td>
                <td><?php echo e($entry->instructor->name ?? 'N/A'); ?></td>
            </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </tbody>
        <tfoot>
            <tr style="background-color: #eee; font-weight: bold;">
                <td colspan="7" style="text-align: right;">TOTAL HORAS EN EL PERIODO:</td>
                <td><?php echo e($entries->sum('total_time')); ?></td>
                <td colspan="6"></td>
            </tr>
        </tfoot>
    </table>

    <div class="footer">Generado el: <?php echo e(now()->format('d/m/Y H:i')); ?></div>
</body>
</html><?php /**PATH E:\Herd\bitacoras\resources\views/reports/pilot_logbook_pdf.blade.php ENDPATH**/ ?>