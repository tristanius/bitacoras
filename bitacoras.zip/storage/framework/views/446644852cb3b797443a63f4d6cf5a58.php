<?php echo $__env->make('partials.alerts', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('partials.monserrat_font', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@700&display=swap" rel="stylesheet">

<?php $__env->startSection('others-content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-xl-7"><img class="bg-img-cover bg-center" src="<?php echo e(asset('assets/images/login/banner.jpeg')); ?>" alt="bg2"></div>
            <div class="col-xl-5 p-0">
                <div class="login-card">
                    <div>
                        <div>
                            <a class="logo" href="<?php echo e(route('dashboard')); ?>">
                                <img class="img-fluid for-light"
                                    src="<?php echo e(asset('assets/images/logo/logo.png')); ?>" style="width: 70%" alt="logo Image">
                            </a>
                        </div>
                        <div class="login-main">
                            <form class="theme-form" method="POST" action="<?php echo e(route('login')); ?>">
                                <?php echo csrf_field(); ?>
                                <h2 class="text-center">Ingresa a tu cuenta</h2>
                                <p class="text-center">Ingrese su correo y su contraseña para iniciar</p>
                                <div class="form-group">
                                    <label class="col-form-label">Correo Electrónico</label>
                                    <input class="form-control" type="email" name="email" id="email" required="" placeholder="Test@gmail.com">
                                </div>
                                <div class="form-group">
                                    <label class="col-form-label">Contraseña</label>
                                    <div class="form-input position-relative">
                                        <input class="form-control" type="password" name="password" id="password" required=""
                                            placeholder="*********">
                                        <div class="show-hide"><span class="show"> </span></div>
                                    </div>
                                </div>
                                <div class="form-group mb-0">
                                    <div class="checkbox p-0">
                                        <input id="checkbox1" type="checkbox">
                                        <label class="text-muted" for="checkbox1">Recordar contraseña</label>
                                    </div><a class="link" href="<?php echo e(route('password.request')); ?>">olvidó su contraseña?</a>
                                    <div class="text-end mt-3">
                                        <button class="btn btn-primary btn-block w-100" type="submit">Ingresar</button>
                                    </div>
                                </div>
                                <div class="login-social-title">
                                    <h3>Registro</h3>
                                </div>
                                <div class="form-group">
                                    
                                </div>
                                <p class="mt-4 mb-0 text-center">¿No tienes una cuenta?<a class="ms-2"
                                        href="<?php echo e(route('register')); ?>">Crear cuenta</a></p>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('others.layout_others.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\Herd\bitacoras\resources\views/auth/login.blade.php ENDPATH**/ ?>