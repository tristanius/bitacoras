<!DOCTYPE html>
<html>
<head>
    <title>Logbook Aeronave - <?php echo e($aircraft->registration); ?></title>
    <style>
        body { font-family: sans-serif; font-size: 10px; color: #333; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #444; padding: 5px; text-align: center; }
        th { background-color: #e9ecef; color: #000; font-weight: bold; }
        .header { text-align: center; margin-bottom: 25px; border-bottom: 2px solid #0b5394; padding-bottom: 10px; }
        .header h2 { margin: 0; color: #0b5394; }
        .footer { position: fixed; bottom: 0; width: 100%; text-align: right; font-size: 8px; font-style: italic; }
        .total-row { background-color: #f8f9fa; font-weight: bold; }
    </style>
</head>
<body>
    <div class="header">
        <h2>REPORTE HISTÓRICO DE AERONAVE</h2>
        <p>
            Matrícula: <strong><?php echo e($aircraft->registration); ?></strong> | 
            Modelo: <strong><?php echo e($aircraft->model->name?? 'N/A'); ?> / <?php echo e($aircraft->model->category->name ?? 'N/A'); ?></strong><br>
            Periodo de Consulta: <?php echo e(\Carbon\Carbon::parse($request->start_date)->format('d/m/Y')); ?> al <?php echo e(\Carbon\Carbon::parse($request->end_date)->format('d/m/Y')); ?>

        </p>
    </div>

    <table>
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Piloto al Mando</th>
                <th>Origen</th>
                <th>Destino</th>
                <th>Hobbs Salida</th>
                <th>Hobbs Entrada</th>
                <th>Tiempo Total</th>
                <th>Aterrizajes (D/N)</th>
                <th>Check instruc.</th>
            </tr>
        </thead>
        <tbody>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::openLoop(); ?><?php endif; ?><?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::startLoop($loop->index); ?><?php endif; ?>
            <tr>
                <td><?php echo e(\Carbon\Carbon::parse($entry->date)->format('d/m/Y')); ?></td>
                <td><?php echo e($entry->pilot->name); ?></td>
                <td><?php echo e($entry->origin->icao_code); ?></td>
                <td><?php echo e($entry->destination->icao_code); ?></td>
                <td><?php echo e(number_format($entry->hobbs_out, 1)); ?></td>
                <td><?php echo e(number_format($entry->hobbs_in, 1)); ?></td>
                <td style="background-color: #fff9db;"><strong><?php echo e(number_format($entry->total_time, 1)); ?></strong></td>
                <td><?php echo e($entry->landings_day); ?> / <?php echo e($entry->landings_night); ?></td>
                <td><?php echo e((isset($entry->instructor_id))? (($entry->validated && $entry->instructor_id)  ? 'VALIDADO' : 'NO VALIDADO') : 'N/A'); ?></td>
            </tr>
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::endLoop(); ?><?php endif; ?><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php \Livewire\Features\SupportCompiledWireKeys\SupportCompiledWireKeys::closeLoop(); ?><?php endif; ?>
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="6" style="text-align: right;">TOTAL HORAS VOLADAS EN EL PERIODO:</td>
                <td style="background-color: #dbe4ff;"><?php echo e(number_format($entries->sum('total_time'), 1)); ?> hrs</td>
                <td colspan="2"></td>
            </tr>
        </tfoot>
    </table>

    <div class="footer">
        Generado por Sistema de Bitácora - <?php echo e(now()->format('d/m/Y H:i')); ?>

    </div>
</body>
</html><?php /**PATH E:\Herd\bitacoras\resources\views/reports/aircraft_logbook_pdf.blade.php ENDPATH**/ ?>